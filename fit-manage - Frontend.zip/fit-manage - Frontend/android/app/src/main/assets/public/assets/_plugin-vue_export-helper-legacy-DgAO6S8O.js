System.register([],(function(t,e){"use strict";return{execute:function(){t("_",((t,e)=>{const c=t.__vccOpts||t;for(const[n,r]of e)c[n]=r;return c}))}}}));
