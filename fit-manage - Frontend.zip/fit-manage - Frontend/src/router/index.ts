import { createRouter, createWebHistory } from '@ionic/vue-router';
import { RouteRecordRaw } from 'vue-router';
import TabsPage from '../views/TabsPage.vue';


const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    redirect: '/login'
  },
  {
    path: '/login',
    component: () => import('../views/Login.vue')
  },
  ,  
  {
    path: '/Facturas',
    component: () => import('../views/FacturaPage.vue')
  },
  {
    path: '/tabs/',
    component: TabsPage,
    children: [
      {
        path: '',
        redirect: '/tabs/'
      },
      {
        path: 'actualizar',
        component: () => import('@/views/ActualizarPage.vue')
      },
      {
        path: 'planes',
        component: () => import('@/views/PlanesPage.vue')
      },
      {
        path: 'clases',
        component: () => import('@/views/ClasesPage.vue')
      }
    ]
  }
];

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes
});

// Guarda global para verificar autenticación
router.beforeEach((to, from, next) => {
  // Rutas permitidas sin autenticación
  const publicRoutes = ['/login'];
  
  // Si la ruta es pública, continúa
  if (publicRoutes.includes(to.path)) {
    next();
  } else {
    // Verificar si el usuario está autenticado
    const isAuthenticated = !!localStorage.getItem('clienteId');
    
    if (isAuthenticated) {
      next();
    } else {
      next('/login'); // Redirige al login si no está autenticado
    }
  }
});

export default router;
