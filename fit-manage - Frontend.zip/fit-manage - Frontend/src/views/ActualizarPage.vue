<template>
  <ion-page>
    <ion-content>
      <div class="background-container"></div>
      <h2 class="title">Editar Perfil</h2>
      
      <form @submit.prevent="updateCliente">
        <ion-item>
          <ion-label position="stacked">Nombre</ion-label>
          <ion-input v-model="cliente.nombre" placeholder="Ingresa el nombre"></ion-input>
        </ion-item>

        <ion-item>
          <ion-label position="stacked">Apellido</ion-label>
          <ion-input v-model="cliente.apellido" placeholder="Ingresa el apellido"></ion-input>
        </ion-item>

        <ion-item>
          <ion-label position="stacked">Teléfono</ion-label>
          <ion-input v-model="cliente.telefono" placeholder="Ingresa el teléfono"></ion-input>
        </ion-item>

        <ion-item>
          <ion-label position="stacked">Dirección</ion-label>
          <ion-input v-model="cliente.direccion" placeholder="Ingresa la dirección"></ion-input>
        </ion-item>

        <ion-item>
          <ion-label position="stacked">Documento</ion-label>
          <ion-input v-model="cliente.documento" placeholder="Ingresa el documento"></ion-input>
        </ion-item>

        <ion-item>
          <ion-label position="stacked">Fecha de Nacimiento</ion-label>
          <ion-datetime display-format="YYYY-MM-DD" v-model="cliente.fechaNacimiento"></ion-datetime>
        </ion-item>

        <ion-item>
          <ion-label position="stacked">Email</ion-label>
          <ion-input v-model="cliente.email" placeholder="Ingresa el email" type="email" disabled></ion-input>
        </ion-item>

        <ion-button expand="block" color="primary" class="action-button" @click="updateCliente">
          Guardar Cambios
        </ion-button>
      </form>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import { IonPage, IonContent, IonItem, IonLabel, IonInput, IonButton, IonDatetime } from '@ionic/vue';
import axios from 'axios';
import { ref, onMounted } from 'vue';
import { API_BASE_URL } from '@/config';

const cliente = ref({
  nombre: '',
  apellido: '',
  telefono: '',
  direccion: '',
  documento: '',
  fechaNacimiento: '',
  email: ''
});

// Obtener el ID del cliente desde localStorage
const clienteId = localStorage.getItem('clienteId');

// Función para cargar la información del cliente
const fetchCliente = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/obtener/${clienteId}`);
    if (response.data) {
      cliente.value = response.data;
    } else {
      alert("Error al cargar los datos del cliente.");
    }
  } catch (error) {
    console.error(error);
    alert("Error al cargar los datos del cliente.");
  }
};

// Función para actualizar los datos del cliente
const updateCliente = async () => {
  try {
    // Filtrar los campos que no son nulos o vacíos
    const updatedData = {};
    Object.keys(cliente.value).forEach(key => {
      if (cliente.value[key] !== null && cliente.value[key] !== '') {
        updatedData[key] = cliente.value[key];
      }
    });

    const response = await axios.put(`${API_BASE_URL}/actualizar/${clienteId}`, updatedData);
    if (response.data) {
      alert("Perfil actualizado exitosamente");
    } else {
      alert("Error al actualizar el perfil");
    }
  } catch (error) {
    console.error("Error al actualizar el perfil:", error.response?.data || error.message);
    alert("Error al actualizar el perfil");
  }
};


// Cargar la información del cliente al montar el componente
onMounted(fetchCliente);
</script>

<style scoped>
.background-container {
  padding: 20px;
}

.title {
  text-align: center;
  font-size: 1.5em;
  margin-bottom: 20px;
}

.action-button {
  margin-top: 20px;
}
</style>
