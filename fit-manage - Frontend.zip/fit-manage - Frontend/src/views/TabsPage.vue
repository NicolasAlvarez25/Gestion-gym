<template>
  <ion-page>
    <ion-tabs>
      <ion-router-outlet></ion-router-outlet>
      <ion-tab-bar slot="bottom">
        <ion-tab-button tab="actualizar" href="/tabs/actualizar">
          <ion-icon aria-hidden="true" :icon="person" />
          <ion-label>Actualizar</ion-label>
        </ion-tab-button>

        <ion-tab-button tab="planes" href="/tabs/planes">
          <ion-icon aria-hidden="true" :icon="duplicate" />
          <ion-label>Planes</ion-label>
        </ion-tab-button>

        <ion-tab-button tab="clases" href="/tabs/clases">
          <ion-icon aria-hidden="true" :icon="calendar" />
          <ion-label>Clases</ion-label>
        </ion-tab-button>

        <ion-tab-button tab="exit" @click="handleLogout">
          <ion-icon aria-hidden="true" :icon="exit" />
          <ion-label>Salir</ion-label>
        </ion-tab-button>
      </ion-tab-bar>
    </ion-tabs>
  </ion-page>
</template>

<script setup lang="ts">
import { IonTabBar, IonTabButton, IonTabs, IonLabel, IonIcon, IonPage, IonRouterOutlet } from '@ionic/vue';
import { duplicate, calendar, person, exit } from 'ionicons/icons';
import { useRouter } from 'vue-router';

const router = useRouter();

const handleLogout = () => {
  // Limpiar variables globales aquí
  clearGlobalVariables();

  // Redirigir al usuario a la página de inicio o login
  router.push('/');
};

const clearGlobalVariables = () => {
  // Si usas un objeto para almacenar variables globales
  // globalVariables es un objeto que deberías definir en algún lugar de tu aplicación
  window.globalVariables = {}; // Limpiar el objeto

  // Si usas localStorage para almacenar información
  localStorage.removeItem('userData'); // Ejemplo de limpieza de datos en localStorage
  // Puedes agregar más claves según sea necesario
};
</script>
c